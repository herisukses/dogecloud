<?Php
 setcookie("CML", "de", 0x7FFFFFFF ,'/');
 header('Location:../');
?>