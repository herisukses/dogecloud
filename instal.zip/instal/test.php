<?Php
  echo $_COOKIE["CML"];
?>