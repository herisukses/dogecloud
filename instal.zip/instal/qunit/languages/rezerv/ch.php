<?Php
$imgFlag = "images/China.png";
$MHeadC1 = "CMine試圖使採礦作為簡單和所有人都可訪問";
$MHeadC2 = "我們強大的現代化設備，你可以得到比特幣和狗幣";
$MpHead1 = "選擇Sha-256算法或Scrypt";
$BtnReg = "創建一個帳戶";
$LMenu = "菜單";
$LPass = "忘記密碼";
$LPass1 = "輸入您的電子郵件地址和登錄下面重置您的密碼";
$LPass2 = "找回密碼";
$LCanc = "取消";
$LBtnConf = "確認";
$LtLog = "登錄";
$LtPass = "密碼";
$LtCPass = "確認密碼";
$LtMail = "電子郵件";
$LAuth = "授權";
$LCLan = "選擇語言";
$LDash = "";
$LBuy = "";
$LHist = "";
$LUsp = "";
$LHlp = "";
$LSupp = "";
?>