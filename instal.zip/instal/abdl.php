<?Php
mysql_connect ("localhost","smchash","qaz123wsx123");
mysql_select_db ("vlapun");
?>