<?Php
 setcookie("CML", "es", 0x7FFFFFFF ,'/');
 header('Location:../');
?>