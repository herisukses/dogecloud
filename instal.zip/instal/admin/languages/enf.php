<?Php
 setcookie("CML", "en", 0x7FFFFFFF ,'/');
 header('Location:../');
?>