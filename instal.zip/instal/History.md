
0.0.2 / 2014-04-26
==================

  * Disabled slider handle cursor
  * Add remotes to fix 301 redirects
  * Do not allow negative step values
  * Remove <IE9 related optimizations
  * Update changelog and bower ignored files

0.0.1 / 2014-03-17
==================

  * Initial release