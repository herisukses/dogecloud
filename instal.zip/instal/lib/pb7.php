<?Php
$apiKey = "";   //apikey
$version = 2; // API version
$pin = "";      //pin
$DVaddress = ""; // address
// 7
?>