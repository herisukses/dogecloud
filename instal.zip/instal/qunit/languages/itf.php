<?Php
 setcookie("CML", "it", 0x7FFFFFFF ,'/');
 header('Location:../');
?>