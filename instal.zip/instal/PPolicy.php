<!DOCTYPE html>

<html>

<head>
  <title>Privacy Poclicy</title>
</head>

<body>

	<!-- Main -->
				<article id="main">
                                  <div id="google_translate_element" align = "center"></div><script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', autoDisplay: false}, 'google_translate_element');
}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
					<header class="special container">
                    <h1>Privacy Policy</h1>
						<span class="icon fa-align-left"></span>
              <p align="center"><br>
                The  Website Owner, including subsidiaries and affiliates ("Website" or  "Website Owner" or "we" or "us" or "our") provides the information  contained in this site or any of the pages comprising the website ("  Site ") to visitors (" visitors ") (collectively referred to as" you  "or" your "hereinafter) in accordance with the conditions of service  set out in the terms of this website service, privacy policy and any  other relevant service conditions, policies and notices which may be  applicable to a particular section or module of this website.<br>
  <br>
                Our commitment to privacy<br>
  <br>
                Your  privacy is very important to us. To better protect your privacy we  provide this notice explaining our online information practices and the  choices you can make about the way your information is collected and  used. To make this notice easy to find, we make it available on our  homepage and at every point where it can be requested personal  information.<br>
  <br>
                Our commitment to data security<br>
  <br>
                To  prevent unauthorized access, maintain data accuracy, and ensure the  correct use of information, we have put in place appropriate physical,  electronic and managerial procedures to safeguard and secure the  information we collect online.<br>
                Providers<br>
  <br>
                We  reserve the right to hire third-party companies and individuals to  provide services on our behalf, the provision of related services, and  assist us in analyzing how our service is used.<br>
  <br>
                These  service providers have access to your personal information only to  perform these tasks on our behalf and have no right to disclose the  information or use it for any other purposes.<br>
                Compliance with Laws<br>
  <br>
                The  security of your personal information is important to us, but remember  that none of the methods of data transmission over the Internet or  stored on electronic media is not 100% secure. While we strive to  provide an economically acceptable means to protect your personal  information, we can not guarantee its absolute security.<br>
                International data transfer<br>
  <br>
                Your  acceptance of this Privacy Policy should be in providing you this  information, which automatically means your consent to the transfer.<br>
                Links to other sites<br>
  <br>
                Our  service may contain links to other sites that are not controlled by us.  If you click on the link a third party, you will be redirected to the  website of a third party. We strongly recommend that you view the  privacy policy of each site you visit.<br>
  <br>
                Privacy of children<br>
  <br>
                Our services are not intended for persons under 13 years of age ("Children").<br>
  <br>
                We  can get information from children under the age of 13 years. If you are  a parent or guardian, and you know that your child has provided us with  personal information, please contact us. If we discover that a child  under the age of 13 years has provided us with personal information, we  will immediately remove this information from our servers.<br>
                Changes to Privacy Policy<br>
  <br>
                We  may update our Privacy Policy from time to time. We will notify you of  any changes by posting the new Privacy Policy on this page.<br>
  <br>
                You  are advised to regularly prosmotraivat this Privacy Policy for changes.  Changes to the Privacy Policy will take effect upon publication on this  page.<br>
                Access, modify, update and correction of personal information<br>
  <br>
                You  will at all times have the right to access your personal information,  which is used CMINE mining, on request completely free without any  - any cost. Moreover, you have the right to correct any of your  personal data, which were not correct, you can also request to cancel  or delete your personal information.<br>

                </p>

					</header>

				</article>

</body>
</html>