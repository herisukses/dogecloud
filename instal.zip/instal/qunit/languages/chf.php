<?Php
 setcookie("CML", "ch", 0x7FFFFFFF ,'/');
 header('Location:../');
?>